<?php
ob_start();
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 'On');
date_default_timezone_set('Europe/Madrid');
setlocale(LC_ALL, 'es_ES');
require_once '../resources/config.php';

$jugadores = array();
$parejas = array();
$vsduelo = array();

/* $_POST['vsgrupo'] = 4;
$grupo = $_POST['vsgrupo'];
$_POST['vsnumber'] = 7;
$_POST['factor'] = 2; */

//Iniciamos jugadores
$sql = "SELECT * FROM participantes WHERE participantes.ptleagid = " . $_POST['leagueId'] . "; ";

if ($result = $connection->query($sql)) {
    while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
        array_push($jugadores, $row['ptusrid']);
    }
}

shuffle($jugadores);
$iteraciones = count($jugadores) - 1;
$salida = 0;

$sqlLiga = "SELECT * from league where lgid = " . $_POST['leagueId'] . "; ";
$resLiga = $connection->query($sqlLiga);
$rowLiga = $resLiga->fetch_array(MYSQLI_ASSOC);
/* $rowLiga = array_map('utf8_encode', $rowLiga); */

switch ($rowLiga['lgtipo']) {
    case 'LIG':
        switch ($rowLiga['lgtipduel']) {
            case '4VS':
                $_POST['vsgrupo'] = 4;
                break;
            case '1VS':
                $_POST['vsgrupo'] = 2;
                break;
            case 'CMP':
                $_POST['vsgrupo'] = 1;
                break;
        }
        $_POST['vsnumber'] = $rowLiga['lgnumpart'];
        $_POST['factor'] = 2;
        $grupo = $_POST['vsgrupo'];

        if ($grupo == 4) {
            //Inicio ARRAY
            $vs[] = array($jugadores[0], $jugadores[1], $jugadores[2], $jugadores[3]);
            for ($i = 0; $i <= $iteraciones; $i++) {
                for ($j = 0; $j <= $iteraciones; $j++) {
                    for ($k = 0; $k <= $iteraciones; $k++) {
                        for ($l = 0; $l <= $iteraciones; $l++) {
                            $repetido = false;
                            foreach ($vs as $keyVs => $valueVs) {
                                //comprobar repetidos
                                $previo = array($jugadores[$i], $jugadores[$j], $jugadores[$k], $jugadores[$l]);
                                $comprobado = array_unique($previo);
                                if (count($comprobado) == $grupo) {
                                    if (count(array_diff($valueVs, array($jugadores[$i], $jugadores[$j], $jugadores[$k], $jugadores[$l]))) < $_POST['factor']) {
                                        $repetido = true;
                                    }
                                } else {
                                    $repetido = true;
                                }
                            }
                            if (!$repetido) {
                                $duelo = array($jugadores[$i], $jugadores[$j], $jugadores[$k], $jugadores[$l]);
                                if (count($duelo) == $grupo) {
                                    $vs[] = $duelo;
                                }
                            }
                        }
                    }
                }
            }
            $i = 1;
            shuffle($vs);
            foreach ($vs as $value) {
                $insVs = "INSERT INTO versus (ennumvs, enlgid, enusrid) VALUES ($i, " . $_POST['leagueId'] . ", " . $value[0] . ")";
                $connection->query($insVs);
                $insVs = "INSERT INTO versus (ennumvs, enlgid, enusrid) VALUES ($i, " . $_POST['leagueId'] . ", " . $value[1] . ")";
                $connection->query($insVs);
                $insVs = "INSERT INTO versus (ennumvs, enlgid, enusrid) VALUES ($i, " . $_POST['leagueId'] . ", " . $value[2] . ")";
                $connection->query($insVs);
                $insVs = "INSERT INTO versus (ennumvs, enlgid, enusrid) VALUES ($i, " . $_POST['leagueId'] . ", " . $value[3] . ")";
                $connection->query($insVs);
                $i++;
            }
        }

        if ($grupo == 1) {
            foreach ($jugadores as $value) {
                $insVs = "INSERT INTO versus (ennumvs, enlgid, enusrid) VALUES (1, " . $_POST['leagueId'] . ", " . $value . ")";
                $connection->query($insVs);
            }
        }
        if ($grupo == 2) {
            $totalRounds  = 1;
            $totalTeams = count($jugadores);
            $vs = 1;
        
            // Crear una lista de todos los enfrentamientos posibles
            $enfrentamientos = array();
        
            for ($homeTeam = 0; $homeTeam < $totalTeams - 1; $homeTeam++) {
                for ($awayTeam = $homeTeam + 1; $awayTeam < $totalTeams; $awayTeam++) {
                    $enfrentamientos[] = array('home' => $homeTeam, 'away' => $awayTeam);
                }
            }
        
            // Barajar los enfrentamientos
            shuffle($enfrentamientos);
        
            for ($round = 1; $round < $totalRounds + 1; $round++) {
                foreach ($enfrentamientos as $enfrentamiento) {
                    $homeTeam = $enfrentamiento['home'];
                    $awayTeam = $enfrentamiento['away'];
        
                    $insVs = "INSERT INTO versus (ennumvs, enlgid, enusrid) VALUES ($vs, " . $_POST['leagueId'] . ", " . $jugadores[$homeTeam] . ")";
                    $connection->query($insVs);
                    $insVs = "INSERT INTO versus (ennumvs, enlgid, enusrid) VALUES ($vs, " . $_POST['leagueId'] . ", " . $jugadores[$awayTeam] . ")";
                    $connection->query($insVs);
                    $vs++;
                }
            }
        }
        
        break;

    case 'COM':
        break;
    case 'TOR':
        $vsTot = $rowLiga['lgnumpart'] - 1;
        $fasesTot = intval(log($rowLiga['lgnumpart'], 2));
        $resto = $rowLiga['lgnumpart'] - pow(2, $fasesTot);
        $asimetrico = false;
        if ($resto > 0) {
            $fasesTot++;
            $asimetrico = true;
            $jugadoresFase1 = array_slice($jugadores, 0, $resto * 2);
            $jugadoresFase2 = array_slice($jugadores, $resto * 2);
        }
        $vs = 1;
        $fase = 1;
        $segundo = false;
        /* var_dump($fasesTot);
        var_dump($resto);
        var_dump($vsTot);
        var_dump($jugadoresFase1); */
        while ($fase <= $fasesTot) {
            if ($fase == 1) {
                if ($asimetrico) {
                    foreach ($jugadoresFase1 as $value) {
                        $insVs = "INSERT INTO versusTor (vsidtor, vsnumvs, vswinvs, vsidusr, vstxtvs, vstfase) VALUES (" . $_POST['leagueId'] . ", $vs, 0, " . $value . ", 'FASE " . $fase . "', $fase)";
                        /* var_dump($insVs); */
                        $connection->query($insVs);
                        if ($segundo) {
                            $jugadoresFase2["VS$vs"] = $vs;
                            $vs++;
                            $segundo = false;
                        } else {
                            $segundo = true;
                        }
                    }
                } else {
                    foreach ($jugadores as $value) {
                        $insVs = "INSERT INTO versusTor (vsidtor, vsnumvs, vswinvs, vsidusr, vstxtvs, vstfase) VALUES (" . $_POST['leagueId'] . ", $vs, 0, " . $value . ", 'FASE " . $fase . "', $fase)";
                        /* var_dump($insVs); */
                        $connection->query($insVs);
                        if ($segundo) {
                            $vsFase[$fase + 1][] = $vs;
                            $vs++;
                            $segundo = false;
                        } else {
                            $segundo = true;
                        }
                    }
                }
            } else {
                if ($asimetrico && $fase == 2) {
                    foreach ($jugadoresFase2 as $key => $value) {
                        if (strpos($key, 'VS') === false) {
                            $insVs = "INSERT INTO versusTor (vsidtor, vsnumvs, vswinvs, vsidusr, vstxtvs, vstfase) VALUES (" . $_POST['leagueId'] . ", $vs, 0, " . $value . ", 'FASE " . $fase . "', $fase)";
                        } else {
                            $insVs = "INSERT INTO versusTor (vsidtor, vsnumvs, vswinvs, vsidusr, vstxtvs, vstfase) VALUES (" . $_POST['leagueId'] . ", $vs, " . $value . ", 0, 'FASE " . $fase . "', $fase)";
                        }
                        /* var_dump($insVs); */
                        $connection->query($insVs);
                        if ($segundo) {
                            $vsFase[$fase + 1][] = $vs;
                            $vs++;
                            $segundo = false;
                        } else {
                            $segundo = true;
                        }
                    }
                } else {
                    foreach ($vsFase[$fase] as $value) {
                        $insVs = "INSERT INTO versusTor (vsidtor, vsnumvs, vswinvs, vsidusr, vstxtvs, vstfase) VALUES (" . $_POST['leagueId'] . ", $vs, " . $value . ", 0, 'FASE " . $fase . "', $fase)";
                        /* var_dump($insVs); */
                        $connection->query($insVs);
                        if ($segundo) {
                            $vsFase[$fase + 1][] = $vs;
                            $vs++;
                            $segundo = false;
                        } else {
                            $segundo = true;
                        }
                    }
                }
            }
            $fase++;
        }
        break;
}



$updLea = "UPDATE league set lgready = 1 where lgid = " . $_POST['leagueId'] . "; ";
$connection->query($updLea);
$json['RESPONSE'] = 'SUCCESS';

echo json_encode($json);
